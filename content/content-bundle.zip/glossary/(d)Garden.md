#todo
Broader concept. Includes notions of decentralized gardening
