Markbase builds tools and experiences for digital gardens to cultivate their gardens and communities. [[Markbase Garage]] is Markbase team's workspace. It is a behind-the-scenes look at what we're working on and how we're thinking about Markbase. 

We are building Markbase in public. We do this because we want the Markbase community to see what we're working on, how we're thinking about Markbase, and the opportunity to grow Markbase with us. We believe building in public is the best way cultivate rich and full digital gardening experiences for ourselves and others. 

If [[Markbase Garden Center]] is the fertile soil for Markbase community members to plant seeds, [[Markbase Garage]] is the back messy manure and composting process. If the Garden Center is the soil for Markbase Community members to grow their own gardens, the Garage is the messy manure and compost that makes that soil fertile.

This is us building Markbase, with the garage doors up. Welcome!